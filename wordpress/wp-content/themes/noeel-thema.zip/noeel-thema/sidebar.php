<div class="sidebar">
				<p>This is the side bar</p>
			</div><!-- .sidebar -->