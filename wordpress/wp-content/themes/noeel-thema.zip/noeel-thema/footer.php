<!-- <footer class="footer">
				<p>&copy; Noeël Moeskops</p>
			</footer> --><!-- .footer -->
		
	</body>
</html>