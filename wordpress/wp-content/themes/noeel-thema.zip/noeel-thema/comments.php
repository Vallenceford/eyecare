<div id="commentaar">
    <?php wp_list_comments(); ?>
</div>

<div id="formulier_commentaar">
    <?php comment_form(); ?>
</div>